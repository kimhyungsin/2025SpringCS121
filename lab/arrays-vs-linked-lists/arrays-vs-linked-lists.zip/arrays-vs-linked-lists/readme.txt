/******************************************************************************
 ***   You and your partner's name, if any.                                 ***
 ******************************************************************************/


/**********************************************************************
 * Approximate number of hours to complete this assignment            *
 **********************************************************************/


/******************************************************************************
 ***   Answers to the following questions.                                  ***
 ******************************************************************************/

What is your estimate of the runtime complexity for retrieval of
**an element's index from an Array**?


What is your estimate of the runtime complexity for retrieval of
**an element by index from a LinkedList**?


What is your estimate of the runtime complexity for retrieval of
**an element's index from a LinkedList**?


/******************************************************************************
 ***   Answers to the bonus questions.                                      ***
 ******************************************************************************/

What is your estimate of the runtime complexity for insertion of an element into
**the beginning an Array**?


What is your estimate of the runtime complexity for insertion of an element into
**the middle of an Array**?


What is your estimate of the runtime complexity for insertion of an element into
**the beginning of a LinkedList**?


What is your estimate of the runtime complexity for insertion of an element into
**the middle of a LinkedList**?


/******************************************************************************
 ***   Do you attest that this work is your own, in accordance with the     ***
 ***   statement on academic integrity in the syllabus?                     ***
 ******************************************************************************/

Yes or no?


/******************************************************************************
 ***   List any other comments here.                                        ***
 ******************************************************************************/
