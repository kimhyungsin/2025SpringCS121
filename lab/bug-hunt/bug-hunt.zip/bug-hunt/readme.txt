Programming Assignment: Bug Hunt

/**********************************************************************
 * All teammates' names                                               *
 **********************************************************************/


/**********************************************************************
 * Describe the bug(s) in CodeCount.java:
 * - Give input(s) that trigger the bug(s)
 * - Describe how you fixed the bug(s)
 **********************************************************************/


/**********************************************************************
 * Describe the bug(s) in PairStar.java:
 * - Give input(s) that trigger the bug(s)
 * - Describe how you fixed the bug(s)
 **********************************************************************/


/**********************************************************************
 * Describe the bug(s) in Turtle.java:
 * - Give input(s) that trigger the bug(s)
 * - Describe how you fixed the bug(s)
 **********************************************************************/


/**********************************************************************
 *  Did you receive help from classmates, past CSCI 121 students, or
 *  anyone else? If so, please list their names.  ("A Sunday lab TA"
 *  or "Office hours on Thursday" is ok if you don't know their name.)
 **********************************************************************/

Yes or no?


/**********************************************************************
 *  Did you encounter any serious problems? If so, please describe.
 **********************************************************************/

Yes or no?


/***********************************************************************
 ***   Do you attest that this work is your own, in accordance with  ***
 ***   the statement on academic integrity in the syllabus?          ***
 ***********************************************************************/

Yes or no?


/**********************************************************************
 *  List any other comments here.
 **********************************************************************/

