Programming Assignment: Expressions

/**********************************************************************
 * All teammates' names                                               *
 **********************************************************************/


/**********************************************************************
 * Approximate number of hours to complete this assignment            *
 **********************************************************************/

Number of hours for 1st TEAMMATE's NAME:

Number of hours for 2nd TEAMMATE's NAME:


/**********************************************************************
 *  Did you receive help from classmates, past CSCI 121 students, or
 *  anyone else? If so, please list their names.  ("A Sunday lab TA"
 *  or "Office hours on Thursday" is ok if you don't know their name.)
 **********************************************************************/

Yes or no?


/**********************************************************************
 *  Did you encounter any serious problems? If so, please describe.
 **********************************************************************/

Yes or no?


/***********************************************************************
 ***   Do you attest that this work is your own, in accordance with  ***
 ***   the statement on academic integrity in the syllabus?          ***
 ***********************************************************************/

Yes or no?



/**********************************************************************
 *  List any other comments here.
 **********************************************************************/

