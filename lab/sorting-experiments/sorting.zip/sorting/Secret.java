public class Secret {

    private static void swap(Comparable[] a, int i, int j) {
        Comparable tmp = a[i];
        a[i] = a[j];
        a[j] = tmp;
    }

    private static void sort(Comparable[] a, int i, int j) {
        if (a[i].compareTo(a[j]) > 0) {
            swap(a, i, j);
        }
        if ((j - i + 1) > 2) {
            int t = (j - i + 1) / 3;
            sort(a, i, j - t);
            sort(a, i + t, j);
            sort(a, i, j - t);
        }
    }

    public static void sort(Comparable[] a) {
        sort(a, 0, a.length - 1);
    }
}
