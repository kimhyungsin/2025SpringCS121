import edu.princeton.cs.algs4.Knuth;

public class Mystery {

    private static boolean isSorted(Comparable[] a) {
        for (int i = 0; i < a.length - 1; i++) {
            if (a[i].compareTo(a[i+1]) > 0) {
                return false;
            }
        }
        return true;
    }

    public static void sort(Comparable[] a) {
        while (!isSorted(a)) {
            Knuth.shuffle(a);
        }
    }
}
