import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class ExampleTests {

    @Test
    void math() {
        Assertions.assertEquals(2 + 2, 4);
    }

}
