public class Elevator {
    // TODO Add appropriate instance variables

    /**
     * @param floors   the floors the elevator can travel to
     * @param capacity the maximum capacity of the elevator
     */
    public Elevator(Floor[] floors, int capacity) {
        // TODO Complete this method
    }

    /**
     * @return the current location of the elevator
     */
    public int getLocation() {
        // TODO Complete this method
        return 0;
    }

    /**
     * Ascend one floor.
     *
     * @throws ElevatorException if you try to ascend to a non-existent floor
     */
    public void ascend() throws ElevatorException {
        // TODO Complete this method
    }

    /**
     * Descend one floor.
     *
     * @throws ElevatorException if you try to descend to a non-existent floor
     */
    public void descend() throws ElevatorException {
        // TODO Complete this method
    }

    /**
     * Load the elevator with as many passengers as will fit from the current floor.
     */
    public void load() {
        // TODO Complete this method
    }

    /**
     * Unload all the passengers who want to disembark on the current floor.
     * <p>
     * Passengers who aren't disembarking should maintain the same relative order within the
     * elevator.
     *
     * @return the passengers who disembarked on this floor, in the order they disembarked
     */
    public Iterable<Passenger> unload() {
        // TODO Complete this method
        return null;
    }

    public static void main(String[] args) {

    }
}
