public class ElevatorException extends Exception {
    ElevatorException(String message) {
        super(message);
    }
}
