Programming Assignment: Conditionals & Loops

/**********************************************************************
 *  What is the relationship between the number of steps n of the
 *  random walk and the mean squared distance? By relationship, we mean
 *  something like
 *                       mean squared distance = 126 n^9
 *
 *  Briefly justify your answer based on computational experiments.
 *  Describe the experiments and list several data points.
 *********************************************************************/



/**********************************************************************
 * Approximate number of hours to complete this assignment            *
 **********************************************************************/

Number of hours:


/******************************************************************************
 ***   Did you receive help from classmates, past CSCI 121 students, or     ***
 ***   anyone else? If so, please list their names. ("A Sunday lab TA"      ***
 ***   or "Office hours on Thursday" is ok if you don't know their name.)   ***
 ******************************************************************************/

Yes or no? 


/******************************************************************************
 ***   Do you attest that this work is your own, in accordance with the     ***
 ***   statement on academic integrity in the syllabus?                     ***
 ******************************************************************************/

Yes or no? 


/**********************************************************************
 *  Did you encounter any serious problems? If so, please describe.
 **********************************************************************/

Yes or no?


/**********************************************************************
 *  List any other comments here.                                     
 **********************************************************************/

