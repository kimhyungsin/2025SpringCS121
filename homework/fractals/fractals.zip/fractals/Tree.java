public class Tree {
    /**
     * Draws a tree branch, and potentially sub-branches as well.
     *
     * @param x     the x-coordinate of the base of this branch
     * @param y     the y-coordinate of the base of this branch
     * @param size  the length of this branch
     * @param angle the angle of this branch
     */
    public static void drawBranch(double x, double y, double size, double angle) {
    }

    public static void main(String[] args) {
        drawBranch(0.5, 0, 0.2, Math.PI / 2);
        StdDraw.save("tree.png");
    }
}
