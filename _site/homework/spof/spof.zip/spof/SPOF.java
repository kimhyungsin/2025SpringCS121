public class SPOF {

    public static void main(String[] args) {
    }
}
