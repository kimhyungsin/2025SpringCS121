public class Reverse {
    public static void main(String[] args) {
    }
}
