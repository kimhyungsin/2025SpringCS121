public class Repeat {
    public static void main(String[] args) {
    }
}
