public class Division {
    public static void main(String[] args) {
    }
}
