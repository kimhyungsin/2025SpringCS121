public class SeqRec {
    public static void main(String[] args) {
    }
}
