public class Wheat {
    public static void main(String[] args) {
    }
}
