import edu.princeton.cs.algs4.Graph;
import edu.princeton.cs.algs4.In;

public class GraphDOT {
    /**
     * @param g A Graph object
     * @return The graph represented as Graphiz DOT data
     */
    public static String getDOT(Graph g) {
        String s = "graph {\n";
        // TODO Print vertices and edges in DOT format
        s += "}";
        return s;
    }

    /**
     * Read Graph data from a file or STDIN, then print a Graphiz DOT
     * representation of the graph.
     */
    public static void main(String[] args) {
        Graph g;
        if (args.length > 0) {
            g = new Graph(new In(args[0]));
        }
        else {
            g = new Graph(new In());
        }
        System.out.println(getDOT(g));
    }
}
